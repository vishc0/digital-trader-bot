"""Execution Manager package init"""
